require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const XLSX = require('xlsx');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

// ─── Klasörler ────────────────────────────────────────────────
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const PDF_DIR    = path.join(__dirname, 'pdfs');
const LOGO_DIR   = path.join(__dirname, 'logo');
[UPLOAD_DIR, PDF_DIR, LOGO_DIR].forEach(d => !fs.existsSync(d) && fs.mkdirSync(d));

// ─── Bellekte tutulan veriler ─────────────────────────────────
let fiyatVerisi  = {};
let aktifExcel   = null;
let logoYolu     = null;
const AYARLAR_DOSYA = path.join(__dirname, 'ayarlar.json');

function ayarlariYukle() {
  try {
    if (fs.existsSync(AYARLAR_DOSYA)) {
      const a = JSON.parse(fs.readFileSync(AYARLAR_DOSYA, 'utf8'));
      if (a.logoYolu && fs.existsSync(a.logoYolu)) logoYolu = a.logoYolu;
      if (a.aktifExcel) {
        const excelYolu = path.join(UPLOAD_DIR, 'fiyat-listesi.xlsx');
        if (fs.existsSync(excelYolu)) {
          fiyatVerisi = excelOku(excelYolu);
          aktifExcel  = a.aktifExcel;
        }
      }
    }
  } catch (e) { console.error('Ayar yükleme hatası:', e.message); }
}

function ayarlariKaydet() {
  fs.writeFileSync(AYARLAR_DOSYA, JSON.stringify({ logoYolu, aktifExcel }));
}

// ─── Multer: Excel ────────────────────────────────────────────
const excelUpload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, 'fiyat-listesi.xlsx')
  }),
  fileFilter: (req, file, cb) => cb(null, file.originalname.endsWith('.xlsx') || file.originalname.endsWith('.xls'))
});

// ─── Multer: Logo ─────────────────────────────────────────────
const logoUpload = multer({
  storage: multer.diskStorage({
    destination: LOGO_DIR,
    filename: (req, file, cb) => cb(null, `logo${path.extname(file.originalname).toLowerCase()}`)
  }),
  fileFilter: (req, file, cb) => cb(null, ['image/png','image/jpeg','image/jpg'].includes(file.mimetype)),
  limits: { fileSize: 2 * 1024 * 1024 }
});

// ─── Excel Parse (SÜTUN bazlı) ────────────────────────────────
// Format: 
//   A1=Ürün Adı  B1=Birim  C1=İstanbul  D1=Ankara  E1=İzmir ...
//   A2=Elma      B2=kg     C2=12.50     D2=11.00   E2=13.00
function excelOku(dosyaYolu) {
  const workbook   = XLSX.readFile(dosyaYolu);
  const sheetName  = workbook.SheetNames[0];
  const sheet      = workbook.Sheets[sheetName];
  const satirlar   = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });

  if (satirlar.length < 2) return {};

  const baslik     = satirlar[0].map(b => String(b).trim());
  const ilSutunlar = baslik.slice(2); // C sütunundan itibaren iller

  const veri = {};
  ilSutunlar.forEach(il => { if (il) veri[il] = []; });

  for (let i = 1; i < satirlar.length; i++) {
    const satir   = satirlar[i];
    const urunAdi = String(satir[0] || '').trim();
    const birim   = String(satir[1] || 'adet').trim();
    if (!urunAdi) continue;

    ilSutunlar.forEach((il, idx) => {
      if (!il) return;
      const fiyat = parseFloat(String(satir[idx + 2] || '0').replace(',', '.')) || 0;
      if (fiyat > 0) {
        veri[il].push({ id: `${il}-${i}`, urun: urunAdi, fiyat, birim });
      }
    });
  }
  return veri;
}

// ─── PDF Oluşturucu ───────────────────────────────────────────
function pdfOlustur(siparis, dosyaYolu, firmaAdi) {
  return new Promise((resolve, reject) => {
    const doc    = new PDFDocument({ margin: 40, size: 'A5' });
    const stream = fs.createWriteStream(dosyaYolu);
    doc.pipe(stream);

    const renk     = { mavi: '#0066cc', koyu: '#1a1a2e', gri: '#666666', acik: '#f5f5f5' };
    const genislik = doc.page.width;
    const tabloW   = genislik - 80;
    const col      = { urun: 40, adet: 220, birimF: 268, toplam: 340 };

    // Üst bant
    doc.rect(0, 0, genislik, 65).fill(renk.mavi);

    let textX = 40;
    if (logoYolu && fs.existsSync(logoYolu)) {
      try { doc.image(logoYolu, 40, 8, { height: 48, fit: [48, 48] }); textX = 100; }
      catch(e) {}
    }
    doc.fillColor('white').fontSize(15).font('Helvetica-Bold').text(firmaAdi, textX, 15);
    doc.fillColor('white').fontSize(9).font('Helvetica').text('SİPARİŞ FİŞİ', textX, 35);
    doc.fillColor('white').fontSize(8)
       .text(`Fiş No : ${siparis.fisNo}`, 280, 15, { align: 'right', width: 110 })
       .text(`Tarih  : ${siparis.tarih}`, 280, 27, { align: 'right', width: 110 })
       .text(`İl     : ${siparis.il}`,   280, 39, { align: 'right', width: 110 });

    let y = 78;
    if (siparis.musteriAd) {
      doc.fillColor(renk.gri).fontSize(8).font('Helvetica').text('Müşteri :', 40, y);
      doc.fillColor(renk.koyu).fontSize(9).font('Helvetica-Bold').text(siparis.musteriAd, 100, y);
      y += 16;
    }
    if (siparis.temsilciAd) {
      doc.fillColor(renk.gri).fontSize(8).font('Helvetica').text('Temsilci:', 40, y);
      doc.fillColor(renk.koyu).fontSize(9).font('Helvetica-Bold').text(siparis.temsilciAd, 100, y);
      y += 16;
    }
    y += 6;

    // Tablo başlık
    doc.rect(40, y, tabloW, 18).fill(renk.mavi);
    doc.fillColor('white').fontSize(8).font('Helvetica-Bold');
    doc.text('Ürün Adı',    col.urun+4, y+5);
    doc.text('Adet',        col.adet,   y+5);
    doc.text('Birim Fiyat', col.birimF, y+5);
    doc.text('Toplam',      col.toplam, y+5, { align:'right', width:48 });
    y += 18;

    let araToplam = 0;
    doc.font('Helvetica').fontSize(8);
    siparis.urunler.forEach((item, idx) => {
      const st = item.fiyat * item.adet;
      araToplam += st;
      doc.rect(40, y, tabloW, 16).fill(idx%2===0 ? 'white' : renk.acik);
      doc.fillColor(renk.koyu);
      doc.text(item.urun,                   col.urun+4, y+4, { width: 174 });
      doc.text(`${item.adet} ${item.birim}`,col.adet,   y+4);
      doc.text(`${item.fiyat.toFixed(2)} ₺`,col.birimF, y+4);
      doc.text(`${st.toFixed(2)} ₺`,        col.toplam, y+4, { align:'right', width:48 });
      y += 16;
    });

    const kdv   = araToplam * 0.01;
    const genel = araToplam + kdv;
    y += 8;
    doc.moveTo(40, y).lineTo(genislik-40, y).stroke(renk.gri);
    y += 10;
    doc.fillColor(renk.gri).fontSize(8).font('Helvetica');
    doc.text('Ara Toplam:', 230, y);
    doc.fillColor(renk.koyu).text(`${araToplam.toFixed(2)} ₺`, col.toplam, y, { align:'right', width:48 });
    y += 14;
    doc.fillColor(renk.gri).text('KDV (%1):', 230, y);
    doc.fillColor(renk.koyu).text(`${kdv.toFixed(2)} ₺`, col.toplam, y, { align:'right', width:48 });
    y += 10;
    doc.rect(225, y, genislik-265, 20).fill(renk.mavi);
    doc.fillColor('white').fontSize(9).font('Helvetica-Bold')
       .text('GENEL TOPLAM:', 230, y+5)
       .text(`${genel.toFixed(2)} ₺`, col.toplam, y+5, { align:'right', width:48 });
    y += 32;
    doc.fillColor(renk.gri).fontSize(7).font('Helvetica')
       .text('Bu fiş elektronik olarak oluşturulmuştur.', 40, y, { align:'center', width:tabloW });

    doc.end();
    stream.on('finish', () => resolve(dosyaYolu));
    stream.on('error', reject);
  });
}

// ═══════════ ENDPOINT'LER ═══════════════════════════════════════

app.post('/api/fiyat-listesi/yukle', excelUpload.single('dosya'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ hata: 'Dosya bulunamadı' });
    fiyatVerisi = excelOku(req.file.path);
    aktifExcel  = req.file.originalname;
    ayarlariKaydet();
    const iller = Object.keys(fiyatVerisi);
    const toplamUrun = Object.values(fiyatVerisi).reduce((t,u)=>t+u.length,0);
    res.json({ basarili:true, mesaj:`${iller.length} il, ${toplamUrun} ürün yüklendi`, iller, toplamUrun });
  } catch(err) { res.status(500).json({ hata: err.message }); }
});

app.post('/api/logo/yukle', logoUpload.single('logo'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ hata: 'Logo bulunamadı' });
    logoYolu = req.file.path;
    ayarlariKaydet();
    res.json({ basarili:true, mesaj:'Logo yüklendi', logoUrl:'/api/logo' });
  } catch(err) { res.status(500).json({ hata: err.message }); }
});

app.get('/api/logo', (req, res) => {
  if (!logoYolu || !fs.existsSync(logoYolu)) return res.status(404).end();
  res.sendFile(logoYolu);
});

app.delete('/api/logo', (req, res) => {
  if (logoYolu && fs.existsSync(logoYolu)) fs.unlinkSync(logoYolu);
  logoYolu = null;
  ayarlariKaydet();
  res.json({ basarili:true, mesaj:'Logo silindi' });
});

app.get('/api/iller', (req, res) => {
  res.json({ iller: Object.keys(fiyatVerisi).sort() });
});

app.get('/api/urunler/:il', (req, res) => {
  const il = decodeURIComponent(req.params.il);
  const urunler = fiyatVerisi[il];
  if (!urunler) return res.status(404).json({ hata:`"${il}" bulunamadı` });
  const { ara } = req.query;
  const sonuc = ara ? urunler.filter(u=>u.urun.toLowerCase().includes(ara.toLowerCase())) : urunler;
  res.json({ il, urunler: sonuc });
});

app.post('/api/siparis/olustur', async (req, res) => {
  try {
    const { il, urunler, musteriAd, temsilciAd } = req.body;
    if (!il || !urunler?.length) return res.status(400).json({ hata:'İl ve ürün zorunlu' });
    const firmaAdi = process.env.FIRMA_ADI || 'Şirket Adı';
    const fisNo    = `FIS-${Date.now().toString().slice(-6)}`;
    const tarih    = new Date().toLocaleDateString('tr-TR', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
    const siparis  = { fisNo, tarih, il, urunler, musteriAd, temsilciAd };
    const pdfDosya = path.join(PDF_DIR, `${fisNo}.pdf`);
    await pdfOlustur(siparis, pdfDosya, firmaAdi);
    const araToplam = urunler.reduce((t,u)=>t+u.fiyat*u.adet, 0);
    const kdv = araToplam * 0.01;
    res.json({ basarili:true, fisNo, tarih, pdfUrl:`/api/siparis/pdf/${fisNo}`,
      ozet:{ araToplam:araToplam.toFixed(2), kdv:kdv.toFixed(2), genelToplam:(araToplam+kdv).toFixed(2) }
    });
  } catch(err) { res.status(500).json({ hata: err.message }); }
});

app.get('/api/siparis/pdf/:fisNo', (req, res) => {
  const dosya = path.join(PDF_DIR, `${req.params.fisNo}.pdf`);
  if (!fs.existsSync(dosya)) return res.status(404).end();
  res.download(dosya, `${req.params.fisNo}.pdf`);
});

app.get('/api/saglik', (req, res) => {
  res.json({ durum:'çalışıyor', firmaAdi: process.env.FIRMA_ADI||'Şirket Adı',
    aktifExcel, logoVar:!!(logoYolu&&fs.existsSync(logoYolu)),
    yuklenenIl: Object.keys(fiyatVerisi).length,
    toplamUrun: Object.values(fiyatVerisi).reduce((t,u)=>t+u.length,0) });
});

ayarlariYukle();
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log(`✅ Sunucu: http://localhost:${PORT}`));
