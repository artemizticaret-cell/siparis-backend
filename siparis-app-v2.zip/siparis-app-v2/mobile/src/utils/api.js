// ─── BACKEND URL'İNİZİ BURAYA GİRİN ───────────────────────────
// Railway'e deploy ettikten sonra verilen URL'i yazın
// Örnek: 'https://siparis-app.up.railway.app'
export const API_URL = 'https://RAILWAY-URL-BURAYA.up.railway.app';

// ─── API İstekleri ─────────────────────────────────────────────
export const api = {

  // İlleri getir
  async illeriGetir() {
    const res = await fetch(`${API_URL}/api/iller`);
    if (!res.ok) throw new Error('İller alınamadı');
    return res.json();
  },

  // İle göre ürünleri getir (arama ile)
  async urunleriGetir(il, ara = '') {
    const params = ara ? `?ara=${encodeURIComponent(ara)}` : '';
    const res = await fetch(`${API_URL}/api/urunler/${encodeURIComponent(il)}${params}`);
    if (!res.ok) throw new Error('Ürünler alınamadı');
    return res.json();
  },

  // Sipariş fişi oluştur
  async siparisOlustur({ il, urunler, musteriAd, temsilciAd }) {
    const res = await fetch(`${API_URL}/api/siparis/olustur`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ il, urunler, musteriAd, temsilciAd })
    });
    if (!res.ok) throw new Error('Sipariş oluşturulamadı');
    return res.json();
  },

  // PDF URL
  pdfUrl(fisNo) {
    return `${API_URL}/api/siparis/pdf/${fisNo}`;
  }
};
