import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, ScrollView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { api } from '../utils/api';

export default function AnaSayfa({ navigation }) {
  const [durum, setDurum] = useState(null);
  const [yukleniyor, setYukleniyor] = useState(true);

  useEffect(() => {
    sunucuKontrol();
  }, []);

  async function sunucuKontrol() {
    try {
      setYukleniyor(true);
      const res = await fetch(`${require('../utils/api').API_URL}/api/saglik`);
      const data = await res.json();
      setDurum(data);
    } catch {
      setDurum(null);
    } finally {
      setYukleniyor(false);
    }
  }

  return (
    <ScrollView style={styles.container}>
      {/* Durum Kartı */}
      <View style={[styles.durumKart, { backgroundColor: durum ? '#e8f5e9' : '#fce4ec' }]}>
        {yukleniyor ? (
          <ActivityIndicator color="#0066cc" />
        ) : (
          <>
            <Ionicons
              name={durum ? 'checkmark-circle' : 'alert-circle'}
              size={28}
              color={durum ? '#2e7d32' : '#c62828'}
            />
            <View style={{ marginLeft: 12 }}>
              <Text style={[styles.durumBaslik, { color: durum ? '#2e7d32' : '#c62828' }]}>
                {durum ? 'Sistem Aktif' : 'Bağlantı Kurulamadı'}
              </Text>
              {durum && (
                <Text style={styles.durumAlt}>
                  {durum.yuklenenIl} il · {durum.toplamUrun} ürün yüklü
                </Text>
              )}
            </View>
          </>
        )}
      </View>

      {/* Firma Bilgisi */}
      {durum && (
        <View style={styles.firmaKart}>
          <Text style={styles.firmaAdi}>{durum.firmaAdi}</Text>
          <Text style={styles.firmaBilgi}>Sipariş Yönetim Sistemi</Text>
        </View>
      )}

      {/* Ana Butonlar */}
      <View style={styles.butonlarContainer}>
        <TouchableOpacity
          style={[styles.anaButon, !durum && styles.butonDevre]}
          onPress={() => durum
            ? navigation.navigate('SiparisEkrani')
            : Alert.alert('Bağlantı Yok', 'Önce sunucu bağlantısı kurun.')
          }
        >
          <Ionicons name="add-circle-outline" size={32} color="white" />
          <Text style={styles.anaButonText}>Yeni Sipariş</Text>
          <Text style={styles.anaButonAlt}>Ürün ekle, fiş oluştur</Text>
        </TouchableOpacity>

        <View style={styles.altButonlar}>
          <TouchableOpacity
            style={styles.kucukButon}
            onPress={() => navigation.navigate('AyarlarEkrani')}
          >
            <Ionicons name="settings-outline" size={24} color="#0066cc" />
            <Text style={styles.kucukButonText}>Ayarlar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.kucukButon}
            onPress={sunucuKontrol}
          >
            <Ionicons name="refresh-outline" size={24} color="#0066cc" />
            <Text style={styles.kucukButonText}>Yenile</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Hızlı Bilgi */}
      <View style={styles.bilgiKutu}>
        <Text style={styles.bilgiBaslik}>💡 Nasıl Kullanılır?</Text>
        <Text style={styles.bilgiAdim}>1. İl seçin</Text>
        <Text style={styles.bilgiAdim}>2. Ürün adını yazarak arayın</Text>
        <Text style={styles.bilgiAdim}>3. Adet girin ve sepete ekleyin</Text>
        <Text style={styles.bilgiAdim}>4. Sipariş Fişi Oluştur'a basın</Text>
        <Text style={styles.bilgiAdim}>5. WhatsApp ile gönderin</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f8', padding: 16 },
  durumKart: {
    flexDirection: 'row', alignItems: 'center',
    padding: 16, borderRadius: 12, marginBottom: 12,
    elevation: 2, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4
  },
  durumBaslik: { fontSize: 15, fontWeight: 'bold' },
  durumAlt: { fontSize: 12, color: '#555', marginTop: 2 },
  firmaKart: {
    backgroundColor: '#0066cc', borderRadius: 12,
    padding: 20, alignItems: 'center', marginBottom: 20,
    elevation: 3
  },
  firmaAdi: { color: 'white', fontSize: 20, fontWeight: 'bold' },
  firmaBilgi: { color: 'rgba(255,255,255,0.8)', fontSize: 12, marginTop: 4 },
  butonlarContainer: { marginBottom: 20 },
  anaButon: {
    backgroundColor: '#0066cc', borderRadius: 14,
    padding: 24, alignItems: 'center',
    elevation: 4, shadowColor: '#0066cc', shadowOpacity: 0.3, shadowRadius: 8,
    marginBottom: 12
  },
  butonDevre: { backgroundColor: '#aaa' },
  anaButonText: { color: 'white', fontSize: 18, fontWeight: 'bold', marginTop: 8 },
  anaButonAlt: { color: 'rgba(255,255,255,0.8)', fontSize: 12, marginTop: 2 },
  altButonlar: { flexDirection: 'row', gap: 12 },
  kucukButon: {
    flex: 1, backgroundColor: 'white', borderRadius: 12,
    padding: 16, alignItems: 'center', borderWidth: 1, borderColor: '#ddd',
    elevation: 1
  },
  kucukButonText: { color: '#0066cc', fontSize: 13, fontWeight: '600', marginTop: 4 },
  bilgiKutu: {
    backgroundColor: 'white', borderRadius: 12,
    padding: 16, marginBottom: 30, borderLeftWidth: 4, borderLeftColor: '#0066cc'
  },
  bilgiBaslik: { fontSize: 14, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  bilgiAdim: { fontSize: 13, color: '#555', paddingVertical: 3, paddingLeft: 8 }
});
