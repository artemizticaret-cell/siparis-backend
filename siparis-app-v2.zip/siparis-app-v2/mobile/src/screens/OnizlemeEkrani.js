import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Linking, Share
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { api } from '../utils/api';

export default function OnizlemeEkrani({ route, navigation }) {
  const { siparis, il } = route.params;
  const [indiriliyor, setIndiriliyor] = useState(false);
  const [pdfYolu, setPdfYolu] = useState(null);

  // PDF indir (cihaza kaydet)
  async function pdfIndir() {
    try {
      setIndiriliyor(true);
      const pdfUrl = api.pdfUrl(siparis.fisNo);
      const yerelYol = `${FileSystem.documentDirectory}${siparis.fisNo}.pdf`;

      const indirme = await FileSystem.downloadAsync(pdfUrl, yerelYol);
      if (indirme.status === 200) {
        setPdfYolu(yerelYol);
        return yerelYol;
      } else {
        throw new Error('PDF indirilemedi');
      }
    } catch (err) {
      Alert.alert('Hata', 'PDF indirilemedi: ' + err.message);
      return null;
    } finally {
      setIndiriliyor(false);
    }
  }

  // WhatsApp'a paylaş
  async function whatsappGonder() {
    try {
      // PDF yoksa önce indir
      let yol = pdfYolu;
      if (!yol) {
        yol = await pdfIndir();
        if (!yol) return;
      }

      // Paylaşım destekli mi kontrol et
      const paylasimMevcut = await Sharing.isAvailableAsync();
      if (!paylasimMevcut) {
        Alert.alert('Uyarı', 'Paylaşım bu cihazda desteklenmiyor');
        return;
      }

      // PDF'i paylaş (WhatsApp dahil tüm uygulamalar görünür)
      await Sharing.shareAsync(yol, {
        mimeType: 'application/pdf',
        dialogTitle: `Sipariş Fişi ${siparis.fisNo}`,
        UTI: 'com.adobe.pdf'
      });
    } catch (err) {
      Alert.alert('Hata', err.message);
    }
  }

  // Dosya olarak paylaş
  async function dosyaPaylas() {
    let yol = pdfYolu;
    if (!yol) {
      yol = await pdfIndir();
      if (!yol) return;
    }
    await Sharing.shareAsync(yol, {
      mimeType: 'application/pdf',
      dialogTitle: 'Sipariş Fişini Paylaş'
    });
  }

  const { ozet } = siparis;

  return (
    <ScrollView style={styles.container}>
      {/* Başarı Kartı */}
      <View style={styles.basariKart}>
        <Ionicons name="checkmark-circle" size={48} color="#2e7d32" />
        <Text style={styles.basariBaslik}>Sipariş Fişi Hazır!</Text>
        <Text style={styles.fisNo}>{siparis.fisNo}</Text>
        <Text style={styles.tarih}>{siparis.tarih} · {il}</Text>
      </View>

      {/* Tutar Özeti */}
      <View style={styles.ozetKart}>
        <Text style={styles.ozetBaslik}>💰 Tutar Özeti</Text>
        <View style={styles.ozetSatir}>
          <Text style={styles.ozetEtiket}>Ara Toplam</Text>
          <Text style={styles.ozetDeger}>{ozet.araToplam} ₺</Text>
        </View>
        <View style={styles.ozetSatir}>
          <Text style={styles.ozetEtiket}>KDV (%1)</Text>
          <Text style={styles.ozetDeger}>{ozet.kdv} ₺</Text>
        </View>
        <View style={[styles.ozetSatir, styles.toplamSatir]}>
          <Text style={styles.toplamEtiket}>GENEL TOPLAM</Text>
          <Text style={styles.toplamDeger}>{ozet.genelToplam} ₺</Text>
        </View>
      </View>

      {/* Aksiyon Butonları */}
      <View style={styles.butonlarKart}>
        <Text style={styles.ozetBaslik}>📤 Gönder / Kaydet</Text>

        {/* WhatsApp */}
        <TouchableOpacity
          style={[styles.buton, styles.whatsappButon]}
          onPress={whatsappGonder}
          disabled={indiriliyor}
        >
          {indiriliyor
            ? <ActivityIndicator color="white" />
            : <>
                <Ionicons name="logo-whatsapp" size={24} color="white" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.butonBaslik}>WhatsApp'a Gönder</Text>
                  <Text style={styles.butonAlt}>PDF olarak ilet</Text>
                </View>
              </>
          }
        </TouchableOpacity>

        {/* PDF İndir */}
        <TouchableOpacity
          style={[styles.buton, styles.pdfButon]}
          onPress={pdfIndir}
          disabled={indiriliyor}
        >
          {indiriliyor
            ? <ActivityIndicator color="#0066cc" />
            : <>
                <Ionicons name="download-outline" size={24} color="#0066cc" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={[styles.butonBaslik, { color: '#0066cc' }]}>PDF İndir</Text>
                  <Text style={[styles.butonAlt, { color: '#555' }]}>Cihaza kaydet</Text>
                </View>
              </>
          }
        </TouchableOpacity>

        {/* Paylaş */}
        <TouchableOpacity
          style={[styles.buton, styles.paylasBuon]}
          onPress={dosyaPaylas}
          disabled={indiriliyor}
        >
          <Ionicons name="share-social-outline" size={24} color="#555" />
          <View style={{ marginLeft: 10 }}>
            <Text style={[styles.butonBaslik, { color: '#333' }]}>Farklı Uygulama ile Paylaş</Text>
            <Text style={styles.butonAlt}>E-posta, Telegram vb.</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Yeni Sipariş */}
      <TouchableOpacity
        style={styles.yeniSiparisButon}
        onPress={() => navigation.navigate('SiparisEkrani')}
      >
        <Ionicons name="add-circle-outline" size={20} color="white" />
        <Text style={styles.yeniSiparisText}>Yeni Sipariş Oluştur</Text>
      </TouchableOpacity>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f8' },
  basariKart: {
    backgroundColor: '#e8f5e9', margin: 16, borderRadius: 14,
    padding: 24, alignItems: 'center', elevation: 2
  },
  basariBaslik: { fontSize: 20, fontWeight: 'bold', color: '#2e7d32', marginTop: 10 },
  fisNo: { fontSize: 16, fontWeight: '700', color: '#333', marginTop: 6 },
  tarih: { fontSize: 12, color: '#666', marginTop: 4 },
  ozetKart: {
    backgroundColor: 'white', marginHorizontal: 16,
    borderRadius: 12, padding: 16, marginBottom: 12, elevation: 2
  },
  ozetBaslik: { fontSize: 14, fontWeight: '700', color: '#333', marginBottom: 12 },
  ozetSatir: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#f0f0f0'
  },
  ozetEtiket: { fontSize: 14, color: '#555' },
  ozetDeger: { fontSize: 14, color: '#222', fontWeight: '500' },
  toplamSatir: { borderBottomWidth: 0, marginTop: 4, paddingTop: 10 },
  toplamEtiket: { fontSize: 15, fontWeight: 'bold', color: '#0066cc' },
  toplamDeger: { fontSize: 18, fontWeight: 'bold', color: '#0066cc' },
  butonlarKart: {
    backgroundColor: 'white', marginHorizontal: 16,
    borderRadius: 12, padding: 16, marginBottom: 12, elevation: 2
  },
  buton: {
    flexDirection: 'row', alignItems: 'center',
    padding: 14, borderRadius: 10, marginBottom: 10
  },
  whatsappButon: { backgroundColor: '#25D366' },
  pdfButon: { backgroundColor: '#e3f2fd', borderWidth: 1, borderColor: '#90caf9' },
  paylasBuon: { backgroundColor: '#f5f5f5', borderWidth: 1, borderColor: '#ddd' },
  butonBaslik: { fontSize: 14, fontWeight: '700', color: 'white' },
  butonAlt: { fontSize: 11, color: 'rgba(255,255,255,0.85)', marginTop: 2 },
  yeniSiparisButon: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#0066cc', margin: 16, borderRadius: 12,
    padding: 14, gap: 8, elevation: 3
  },
  yeniSiparisText: { color: 'white', fontSize: 15, fontWeight: 'bold' }
});
