import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, ScrollView, Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { API_URL } from '../utils/api';

export default function AyarlarEkrani() {
  const [excelYukleniyor, setExcelYukleniyor] = useState(false);
  const [logoYukleniyor, setLogoYukleniyor]   = useState(false);
  const [excelSonuc, setExcelSonuc]           = useState(null);
  const [logoSonuc, setLogoSonuc]             = useState(null);
  const [mevcutLogo, setMevcutLogo]           = useState(null);
  const [sunucuDurum, setSunucuDurum]         = useState(null);

  useEffect(() => { durumGetir(); }, []);

  async function durumGetir() {
    try {
      const res  = await fetch(`${API_URL}/api/saglik`);
      const data = await res.json();
      setSunucuDurum(data);
      setMevcutLogo(data.logoVar ? `${API_URL}/api/logo?t=${Date.now()}` : null);
    } catch { setSunucuDurum(null); }
  }

  async function excelYukle() {
    try {
      const dosya = await DocumentPicker.getDocumentAsync({
        type: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-excel'],
        copyToCacheDirectory: true
      });
      if (dosya.canceled) return;
      const secilen = dosya.assets[0];
      setExcelYukleniyor(true);
      setExcelSonuc(null);
      const formData = new FormData();
      formData.append('dosya', { uri: secilen.uri, name: secilen.name, type: secilen.mimeType || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const res  = await fetch(`${API_URL}/api/fiyat-listesi/yukle`, { method:'POST', body:formData, headers:{'Content-Type':'multipart/form-data'} });
      const data = await res.json();
      setExcelSonuc({ basarili: res.ok, mesaj: data.mesaj || data.hata, iller: data.iller });
      durumGetir();
    } catch(err) { Alert.alert('Hata', 'Excel yüklenemedi: ' + err.message); }
    finally { setExcelYukleniyor(false); }
  }

  async function logoSec() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('İzin Gerekli', 'Galeriye erişim izni verin.'); return; }
    const sonuc = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect: [1,1], quality: 0.8,
    });
    if (sonuc.canceled) return;
    const asset = sonuc.assets[0];
    try {
      setLogoYukleniyor(true);
      setLogoSonuc(null);
      const formData = new FormData();
      formData.append('logo', { uri: asset.uri, name: asset.fileName || 'logo.jpg', type: asset.mimeType || 'image/jpeg' });
      const res  = await fetch(`${API_URL}/api/logo/yukle`, { method:'POST', body:formData, headers:{'Content-Type':'multipart/form-data'} });
      const data = await res.json();
      if (res.ok) {
        setMevcutLogo(`${API_URL}/api/logo?t=${Date.now()}`);
        setLogoSonuc({ basarili:true, mesaj:'Logo başarıyla yüklendi ✓' });
      } else {
        setLogoSonuc({ basarili:false, mesaj:data.hata });
      }
      durumGetir();
    } catch(err) { Alert.alert('Hata', 'Logo yüklenemedi: ' + err.message); }
    finally { setLogoYukleniyor(false); }
  }

  async function logoSil() {
    Alert.alert('Logo Sil', 'Silmek istediğinizden emin misiniz?', [
      { text:'İptal', style:'cancel' },
      { text:'Sil', style:'destructive', onPress: async () => {
        try {
          await fetch(`${API_URL}/api/logo`, { method:'DELETE' });
          setMevcutLogo(null);
          setLogoSonuc({ basarili:true, mesaj:'Logo silindi' });
          durumGetir();
        } catch { Alert.alert('Hata','Logo silinemedi'); }
      }}
    ]);
  }

  return (
    <ScrollView style={styles.container}>
      {sunucuDurum && (
        <View style={styles.durumBant}>
          <Ionicons name="checkmark-circle" size={16} color="#2e7d32" />
          <Text style={styles.durumText}>
            {sunucuDurum.firmaAdi}  ·  {sunucuDurum.yuklenenIl} il  ·  {sunucuDurum.toplamUrun} ürün
          </Text>
        </View>
      )}

      {/* LOGO */}
      <View style={styles.kart}>
        <Text style={styles.kartBaslik}>🖼️ Firma Logosu</Text>
        <Text style={styles.aciklama}>Sipariş fişinin sol üst köşesinde görünür. PNG veya JPG, max 2MB.</Text>

        <View style={styles.logoBolum}>
          <View style={styles.logoOnizleme}>
            {mevcutLogo ? (
              <Image source={{ uri: mevcutLogo }} style={styles.logoResim} resizeMode="contain" />
            ) : (
              <View style={styles.logoYok}>
                <Ionicons name="image-outline" size={40} color="#bbb" />
                <Text style={styles.logoYokText}>Logo yüklenmedi</Text>
              </View>
            )}
          </View>

          <View style={styles.logoButonlar}>
            <TouchableOpacity style={[styles.logoButon, logoYukleniyor && styles.butonDevre]} onPress={logoSec} disabled={logoYukleniyor}>
              {logoYukleniyor ? <ActivityIndicator color="white" size="small" /> : (
                <>
                  <Ionicons name="cloud-upload-outline" size={18} color="white" />
                  <Text style={styles.logoButonText}>{mevcutLogo ? 'Değiştir' : 'Logo Yükle'}</Text>
                </>
              )}
            </TouchableOpacity>
            {mevcutLogo && (
              <TouchableOpacity style={styles.silButon} onPress={logoSil}>
                <Ionicons name="trash-outline" size={18} color="#e53935" />
                <Text style={styles.silButonText}>Logoyu Sil</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {logoSonuc && (
          <View style={[styles.sonucKutu, { backgroundColor: logoSonuc.basarili ? '#e8f5e9' : '#fce4ec' }]}>
            <Ionicons name={logoSonuc.basarili ? 'checkmark-circle':'alert-circle'} size={18} color={logoSonuc.basarili ? '#2e7d32':'#c62828'} />
            <Text style={[styles.sonucText, { color: logoSonuc.basarili ? '#2e7d32':'#c62828' }]}>{logoSonuc.mesaj}</Text>
          </View>
        )}
      </View>

      {/* EXCEL */}
      <View style={styles.kart}>
        <Text style={styles.kartBaslik}>📊 Fiyat Listesi (Excel)</Text>
        <Text style={styles.aciklama}>Tek sayfada, her il ayrı sütun olarak tanımlanır.</Text>

        <View style={styles.formatTabloBaslik}>
          {['Ürün Adı','Birim','İstanbul','Ankara','İzmir','...'].map((h,i)=>(
            <Text key={i} style={[styles.hucre, {color:'white',fontWeight:'bold',fontSize:10}]}>{h}</Text>
          ))}
        </View>
        {[['Elma','kg','12.50','11.00','13.50',''],['Ekmek','adet','8.00','7.50','8.50',''],['Süt','lt','25.00','24.00','26.00','']].map((r,i)=>(
          <View key={i} style={styles.formatTablo}>
            {r.map((h,j)=><Text key={j} style={[styles.hucre,{fontSize:11}]}>{h}</Text>)}
          </View>
        ))}

        <View style={styles.notKutu}>
          <Ionicons name="information-circle-outline" size={16} color="#0066cc" />
          <Text style={styles.notText}>
            {'• Tek sayfa (sheet) kullanın\n• A=Ürün Adı, B=Birim, C\'den itibaren iller\n• Fiyatı olmayan illerin hücresi boş kalabilir'}
          </Text>
        </View>

        <TouchableOpacity style={[styles.yukleButon, excelYukleniyor && styles.butonDevre]} onPress={excelYukle} disabled={excelYukleniyor}>
          {excelYukleniyor ? <ActivityIndicator color="white" /> : (
            <>
              <Ionicons name="cloud-upload-outline" size={22} color="white" />
              <Text style={styles.yukleButonText}>Excel Dosyası Yükle</Text>
            </>
          )}
        </TouchableOpacity>

        {excelSonuc && (
          <View style={[styles.sonucKutu, { backgroundColor: excelSonuc.basarili ? '#e8f5e9' : '#fce4ec' }]}>
            <Ionicons name={excelSonuc.basarili ? 'checkmark-circle':'alert-circle'} size={18} color={excelSonuc.basarili ? '#2e7d32':'#c62828'} />
            <View style={{marginLeft:8,flex:1}}>
              <Text style={[styles.sonucText, { color: excelSonuc.basarili ? '#2e7d32':'#c62828' }]}>{excelSonuc.mesaj}</Text>
              {excelSonuc.iller && <Text style={{fontSize:11,color:'#555',marginTop:4}}>İller: {excelSonuc.iller.join(' · ')}</Text>}
            </View>
          </View>
        )}
      </View>

      {/* SUNUCU */}
      <View style={styles.kart}>
        <Text style={styles.kartBaslik}>🌐 Bağlantı</Text>
        <Text style={styles.sunucuUrl}>{API_URL}</Text>
        <Text style={styles.notText}>Değiştirmek için src/utils/api.js dosyasını düzenleyin.</Text>
      </View>

      <View style={{height:40}} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:         { flex:1, backgroundColor:'#f0f4f8', padding:16 },
  durumBant:         { flexDirection:'row', alignItems:'center', backgroundColor:'#e8f5e9', borderRadius:8, padding:10, marginBottom:12, gap:8 },
  durumText:         { fontSize:12, color:'#2e7d32', fontWeight:'600' },
  kart:              { backgroundColor:'white', borderRadius:12, padding:16, marginBottom:14, elevation:2 },
  kartBaslik:        { fontSize:15, fontWeight:'bold', color:'#333', marginBottom:10 },
  aciklama:          { fontSize:13, color:'#555', lineHeight:20, marginBottom:12 },
  logoBolum:         { flexDirection:'row', gap:12, alignItems:'center', marginBottom:12 },
  logoOnizleme:      { width:100, height:100, borderRadius:10, borderWidth:1, borderColor:'#ddd', backgroundColor:'#f9f9f9', overflow:'hidden', justifyContent:'center', alignItems:'center' },
  logoResim:         { width:98, height:98 },
  logoYok:           { alignItems:'center' },
  logoYokText:       { fontSize:11, color:'#bbb', marginTop:4, textAlign:'center' },
  logoButonlar:      { flex:1, gap:10 },
  logoButon:         { flexDirection:'row', alignItems:'center', justifyContent:'center', backgroundColor:'#0066cc', borderRadius:8, padding:11, gap:6 },
  logoButonText:     { color:'white', fontSize:13, fontWeight:'700' },
  silButon:          { flexDirection:'row', alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:'#e53935', borderRadius:8, padding:11, gap:6 },
  silButonText:      { color:'#e53935', fontSize:13, fontWeight:'600' },
  formatTabloBaslik: { flexDirection:'row', backgroundColor:'#0066cc', borderRadius:6, padding:8, marginBottom:2 },
  formatTablo:       { flexDirection:'row', borderBottomWidth:1, borderBottomColor:'#f0f0f0', paddingVertical:5, paddingHorizontal:8 },
  hucre:             { flex:1, fontSize:12, color:'#333' },
  notKutu:           { flexDirection:'row', backgroundColor:'#e3f2fd', borderRadius:8, padding:10, marginTop:10, marginBottom:14, gap:8 },
  notText:           { fontSize:12, color:'#555', lineHeight:18, flex:1 },
  yukleButon:        { flexDirection:'row', alignItems:'center', justifyContent:'center', backgroundColor:'#0066cc', borderRadius:10, padding:14, gap:8 },
  butonDevre:        { backgroundColor:'#aaa' },
  yukleButonText:    { color:'white', fontSize:14, fontWeight:'bold' },
  sonucKutu:         { flexDirection:'row', alignItems:'flex-start', borderRadius:8, padding:12, marginTop:12, gap:8 },
  sonucText:         { fontSize:13, fontWeight:'600', flex:1 },
  sunucuUrl:         { fontFamily:'monospace', fontSize:12, color:'#0066cc', backgroundColor:'#e3f2fd', padding:10, borderRadius:6, marginBottom:8 },
});
