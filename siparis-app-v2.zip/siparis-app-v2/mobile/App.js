import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import AnaSayfa from './src/screens/AnaSayfa';
import SiparisEkrani from './src/screens/SiparisEkrani';
import OnizlemeEkrani from './src/screens/OnizlemeEkrani';
import AyarlarEkrani from './src/screens/AyarlarEkrani';

const Stack = createStackNavigator();

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName="AnaSayfa"
            screenOptions={{
              headerStyle: { backgroundColor: '#0066cc' },
              headerTintColor: '#fff',
              headerTitleStyle: { fontWeight: 'bold' },
            }}
          >
            <Stack.Screen
              name="AnaSayfa"
              component={AnaSayfa}
              options={{ title: '📋 Sipariş Sistemi' }}
            />
            <Stack.Screen
              name="SiparisEkrani"
              component={SiparisEkrani}
              options={{ title: '🛒 Yeni Sipariş' }}
            />
            <Stack.Screen
              name="OnizlemeEkrani"
              component={OnizlemeEkrani}
              options={{ title: '📄 Sipariş Fişi' }}
            />
            <Stack.Screen
              name="AyarlarEkrani"
              component={AyarlarEkrani}
              options={{ title: '⚙️ Ayarlar' }}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
