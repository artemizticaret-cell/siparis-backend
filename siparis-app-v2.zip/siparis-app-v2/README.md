# 📋 Sipariş Sistemi v2 — Kurulum Rehberi

## Yenilikler (v2)
- ✅ Logo yükleme / değiştirme / silme (Ayarlar ekranından)
- ✅ Excel formatı değişti: Tek sayfa, iller sütun bazlı
- ✅ Logo PDF fişinde otomatik görünür
- ✅ Logo yeniden başlatmada kaybolmaz (kalıcı)

---

## Excel Format (YENİ)

Artık tek sayfa yeterli. Her il bir sütun:

| A - Ürün Adı | B - Birim | C - İstanbul | D - Ankara | E - İzmir |
|-------------|-----------|-------------|-----------|----------|
| Elma        | kg        | 12.50       | 11.00     | 13.50    |
| Ekmek       | adet      | 8.00        | 7.50      | 8.50     |
| Süt 1lt     | lt        | 25.00       | 24.00     | 26.00    |

**Kurallar:**
- Sadece 1 sayfa (sheet) kullanın
- İlk satır mutlaka başlık satırı olmalı
- Fiyatı olmayan illerin hücresi boş bırakılabilir
- O ürün o ilde listede görünmez

---

## Logo Yönetimi

Ayarlar ekranında:
1. **"Logo Yükle"** → Telefonun galerisinden seç
2. Kare kırpma ekranı çıkar → Ayarla
3. Logo sunucuya yüklenir → PDF'lerde otomatik görünür
4. **"Değiştir"** veya **"Logoyu Sil"** ile yönetilir

**Önerilen format:** PNG, şeffaf arka plan, 200x200px+

---

## Kurulum (Aynı)

### Backend → Railway
```bash
cd backend && git init && git add . && git commit -m "v2"
# railway.app > GitHub > Deploy
# Env: FIRMA_ADI=Şirket Adı
```

### Mobil
```bash
cd mobile
npm install
# src/utils/api.js içinde API_URL'yi Railway URL ile değiştir
npx expo start
```
